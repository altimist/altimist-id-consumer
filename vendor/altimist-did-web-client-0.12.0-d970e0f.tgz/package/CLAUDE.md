# CLAUDE.md — @altimist/did-web-client

## Working Principles

Behavioural guidelines for coding work. Bias toward caution over speed — for trivial tasks, use judgment.

### 1. Think Before Coding

Don't assume. Don't hide confusion. Surface tradeoffs.

- State assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them — don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

### 2. Simplicity First

Minimum code that solves the problem. Nothing speculative.

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

### 3. Surgical Changes

Touch only what you must. Clean up only your own mess.

- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it.
- Remove imports, variables, and functions that *your* changes made unused. Leave pre-existing dead code alone unless asked.

The test: every changed line should trace directly to the user's request.

### 4. Goal-Driven Execution

Define success criteria. Loop until verified.

Transform vague tasks into verifiable goals:

- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:

    1. [Step] → verify: [check]
    2. [Step] → verify: [check]
    3. [Step] → verify: [check]

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## Spec-First for Substantial Features

Before implementing a substantial feature, check for an existing spec in `docs/specs/`. If none exists, propose drafting one with the user before writing code.

**A feature is "substantial" if it meets any of these:**

- Touches multiple layers (UI + API + DB)
- Adds a new user-facing capability
- Requires a data model change or new database table
- Requires a new API endpoint or external integration
- Will likely take more than ~2 hours of focused work
- Affects security, auth, or permissions

**Trivial work that doesn't need a spec:** bug fixes restoring intended behaviour, refactors with no behavioural change, copy/typo edits, single utility functions, dependency bumps.

**For projects without a `docs/specs/` folder:** the spec-first rule doesn't apply — use the project's own conventions.

## Git Workflow

### Protected branches

- **`main`** is protected. Never push directly.
- All other branches are unrestricted.

### Workflow

- Branch from `main` → commit → push → open PR → review → merge.
- Before opening a PR, check the repo status and the latest PRs to avoid duplicates.

### Self-merge allowed

Non-Vercel project — any team member can open + self-merge after review.

### State verification

- **Verify remote state before claiming it.** Run `gh pr view <n>`, `gh pr list`, `git fetch` before saying "the PR is open" or "main hasn't moved."
- **Pull latest before pushing.**

## Project

`@altimist/did-web-client` is the **consumer-side** library for F-010.
Apps that authenticate Altimist users use this library to verify
identity + Membership VCs against the public surfaces hosted at
`altimist.com`. The library never calls altimist-id at request time —
that's the load-bearing architectural invariant (F-010 US-4).

Counterpart packages:

- **[`@altimist/did-publisher`](https://github.com/altimist/did-publisher)**
  — the publisher-side library consumed by the
  [`altimist-com-router`](https://github.com/altimist/altimist-com-router)
  CF Worker that fronts `*.altimist.com`.

The two halves form the F-010 client/server pair, both in the
`@altimist` npm scope, both ES256-signed end to end.

See [F-010 spec](https://github.com/altimist/altimist-id/blob/main/docs/specs/F-010-finternet-native-identity-phase-2a.md)
§Public Interface and §M7 in the milestones doc.

## Stack

- TypeScript, ESM-only.
- Vitest for tests (mocks `globalThis.fetch`; tests assert no fetch
  is reached during pure-verify paths).
- Targets Node 20+ (also runs on Vercel Edge / Cloudflare Workers).
- Deps: `jose` (JWT-VC sign+verify), `@simplewebauthn/server`
  (WebAuthn assertion verification).

## Commands

```bash
npm install
npm test                # vitest
npm run typecheck       # tsc --noEmit
npm run build           # tsc to dist/
```

## Publishing

Published to npm as `@altimist/did-web-client` under the `@altimist`
scope (public access). Bump version in `package.json`, then
`npm publish`. Consumers pin a specific version.

## Architectural invariants pinned by tests

- `verifyMembershipVC` is **pure** — no `fetch`. Tests spy on
  `globalThis.fetch` and assert zero calls.
- `verifyChallenge` does fetch (the public did.json) but **never**
  calls altimist-id's `/api/auth/*` or `/api/admin/*`. Tests check
  the fetched URL.
- `isRevoked` does fetch the apex revocations list but doesn't
  short-circuit on transient failures — the consumer chooses fail-open
  vs fail-closed (default fail-closed).
- **Key-purpose segregation (F-024).** A key referenced ONLY from
  `capabilityInvocation` (the org-held FinternetPay descriptor-signing
  key) is excluded from every sign-in / bridge-JWT candidate set via
  `signInEligibleVerificationMethods`. Tests pin that `issueChallenge`
  omits it from `allowCredentials`, `verifyChallenge` rejects an
  assertion signed with it (`credential-not-in-doc`), `verifyBridgeJwt`
  rejects it (`kid-not-in-doc` / never a fallback candidate), and
  `getDevices` excludes it. Mirrors altimist-id's
  `signInEligibleVerificationMethods` — keep the two predicates in sync.
- `getPaymentDescriptor` fetches did.json once and the descriptor
  endpoint once, and **nothing else**. Tests assert the exact call count
  (2) and both URLs. It verifies the ES256 proof over the RFC 8785 (JCS)
  canonical descriptor before returning — the JCS canonicaliser
  (`src/jcs.ts`) must stay byte-compatible with altimist-id's
  `src/lib/jcs.ts` or every descriptor fails verification in production.
  The DID-controlled FinternetPay endpoint is SSRF-guarded before any
  request: `https:`-only, no loopback/link-local/private/`localhost`
  hosts, and `redirect: "manual"` (any 3xx is rejected, never followed).
  A 404 returns `null` only for `{ error: "no_payment_source" }` — any
  other 404 body throws. All pinned by tests.
